module todo.app {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    
    opens com.todo to javafx.graphics;
}


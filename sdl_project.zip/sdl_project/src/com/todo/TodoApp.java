package com.todo;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class TodoApp extends Application {
    private DatabaseHandler dbHandler;
    private VBox taskListContainer;
    private ToggleGroup filterGroup;
    private int totalTasks = 0;
    private int completedTasks = 0;

    @Override
    public void start(Stage primaryStage) {
        dbHandler = new DatabaseHandler();
        dbHandler.createTable();

        primaryStage.setTitle("Smart To-Do List");
        primaryStage.setMinWidth(600);
        primaryStage.setMinHeight(700);

        BorderPane root = new BorderPane();
        try {
            root.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());
        } catch (Exception e) {
            System.err.println("Could not load stylesheet: " + e.getMessage());
        }

        // Top Bar
        HBox topBar = createTopBar();
        root.setTop(topBar);

        // Center - Task List
        ScrollPane scrollPane = createScrollableTaskList();
        root.setCenter(scrollPane);

        // Bottom Bar
        HBox bottomBar = createBottomBar();
        root.setBottom(bottomBar);

        Scene scene = new Scene(root, 700, 800);
        primaryStage.setScene(scene);
        primaryStage.show();

        refreshTaskList("all");
    }

    private HBox createTopBar() {
        HBox topBar = new HBox(20);
        topBar.setPadding(new Insets(20));
        topBar.setAlignment(Pos.CENTER);

        Label title = new Label("Smart To-Do List");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        title.getStyleClass().add("app-title");

        Button addTaskBtn = new Button("+ Add Task");
        addTaskBtn.getStyleClass().add("add-task-btn");
        addTaskBtn.setOnAction(e -> showAddTaskDialog());

        HBox.setHgrow(title, Priority.ALWAYS);
        topBar.getChildren().addAll(title, addTaskBtn);

        return topBar;
    }

    private ScrollPane createScrollableTaskList() {
        taskListContainer = new VBox(10);
        taskListContainer.setPadding(new Insets(20));
        taskListContainer.setAlignment(Pos.TOP_CENTER);

        ScrollPane scrollPane = new ScrollPane(taskListContainer);
        scrollPane.setFitToWidth(true);
        scrollPane.getStyleClass().add("scroll-pane");

        return scrollPane;
    }

    private HBox createBottomBar() {
        VBox bottomBar = new VBox(15);
        bottomBar.setPadding(new Insets(20));
        bottomBar.setAlignment(Pos.CENTER);

        // Filter Buttons
        Label filterLabel = new Label("Filter Tasks:");
        filterLabel.setFont(Font.font("Arial", FontWeight.SEMI_BOLD, 14));

        ToggleButton allBtn = new ToggleButton("All");
        ToggleButton pendingBtn = new ToggleButton("Pending");
        ToggleButton completedBtn = new ToggleButton("Completed");

        filterGroup = new ToggleGroup();
        allBtn.setToggleGroup(filterGroup);
        pendingBtn.setToggleGroup(filterGroup);
        completedBtn.setToggleGroup(filterGroup);
        allBtn.setSelected(true);

        allBtn.setOnAction(e -> refreshTaskList("all"));
        pendingBtn.setOnAction(e -> refreshTaskList("pending"));
        completedBtn.setOnAction(e -> refreshTaskList("completed"));

        HBox filterBox = new HBox(10);
        filterBox.setAlignment(Pos.CENTER);
        filterBox.getChildren().addAll(allBtn, pendingBtn, completedBtn);
        filterBox.getStyleClass().add("filter-buttons");

        // Task Count and Actions
        HBox actionBar = new HBox(20);
        actionBar.setAlignment(Pos.CENTER);

        Label taskCountLabel = new Label("Tasks: 0");
        taskCountLabel.setFont(Font.font("Arial", 13));
        taskCountLabel.getStyleClass().add("task-count");

        Button clearCompletedBtn = new Button("Clear Completed");
        clearCompletedBtn.getStyleClass().add("clear-btn");
        clearCompletedBtn.setOnAction(e -> clearCompletedTasks());

        Button exportBtn = new Button("Export Tasks");
        exportBtn.getStyleClass().add("export-btn");
        exportBtn.setOnAction(e -> exportTasks());

        actionBar.getChildren().addAll(taskCountLabel, clearCompletedBtn, exportBtn);

        bottomBar.getChildren().addAll(filterLabel, filterBox, actionBar);

        return new HBox(bottomBar);
    }

    private void showAddTaskDialog() {
        Dialog<Task> dialog = new Dialog<>();
        dialog.setTitle("Add New Task");
        dialog.setHeaderText("Enter task details");

        DialogPane dialogPane = dialog.getDialogPane();
        dialogPane.setPrefSize(400, 300);

        TextField titleField = new TextField();
        titleField.setPromptText("Task title *");

        TextArea descriptionField = new TextArea();
        descriptionField.setPromptText("Task description");
        descriptionField.setPrefRowCount(3);

        DatePicker datePicker = new DatePicker();

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 20, 20, 20));

        grid.add(new Label("Title:"), 0, 0);
        grid.add(titleField, 1, 0);
        grid.add(new Label("Description:"), 0, 1);
        grid.add(descriptionField, 1, 1);
        grid.add(new Label("Due Date:"), 0, 2);
        grid.add(datePicker, 1, 2);

        dialogPane.setContent(grid);

        ButtonType addButtonType = new ButtonType("Add Task", ButtonBar.ButtonData.OK_DONE);
        dialogPane.getButtonTypes().addAll(addButtonType, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == addButtonType && !titleField.getText().trim().isEmpty()) {
                return new Task(
                    0,
                    titleField.getText().trim(),
                    descriptionField.getText().trim(),
                    datePicker.getValue() != null ? datePicker.getValue().toString() : null,
                    false
                );
            }
            return null;
        });

        dialog.showAndWait().ifPresent(task -> {
            dbHandler.addTask(task);
            refreshTaskList(getCurrentFilter());
        });
    }

    private void showEditTaskDialog(Task task) {
        Dialog<Task> dialog = new Dialog<>();
        dialog.setTitle("Edit Task");
        dialog.setHeaderText("Edit task details");

        DialogPane dialogPane = dialog.getDialogPane();
        dialogPane.setPrefSize(400, 300);

        TextField titleField = new TextField(task.getTitle());
        TextArea descriptionField = new TextArea(task.getDescription());
        descriptionField.setPrefRowCount(3);
        DatePicker datePicker = new DatePicker();
        
        if (task.getDueDate() != null) {
            try {
                datePicker.setValue(java.time.LocalDate.parse(task.getDueDate()));
            } catch (Exception e) {
                // Date parsing failed, leave empty
            }
        }

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 20, 20, 20));

        grid.add(new Label("Title:"), 0, 0);
        grid.add(titleField, 1, 0);
        grid.add(new Label("Description:"), 0, 1);
        grid.add(descriptionField, 1, 1);
        grid.add(new Label("Due Date:"), 0, 2);
        grid.add(datePicker, 1, 2);

        dialogPane.setContent(grid);

        ButtonType saveButtonType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialogPane.getButtonTypes().addAll(saveButtonType, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == saveButtonType && !titleField.getText().trim().isEmpty()) {
                return new Task(
                    task.getId(),
                    titleField.getText().trim(),
                    descriptionField.getText().trim(),
                    datePicker.getValue() != null ? datePicker.getValue().toString() : null,
                    task.isCompleted()
                );
            }
            return null;
        });

        dialog.showAndWait().ifPresent(updatedTask -> {
            dbHandler.updateTask(updatedTask);
            refreshTaskList(getCurrentFilter());
        });
    }

    private void refreshTaskList(String filter) {
        taskListContainer.getChildren().clear();
        java.util.List<Task> tasks;

        switch (filter) {
            case "pending":
                tasks = dbHandler.getAllTasks().stream()
                    .filter(task -> !task.isCompleted())
                    .collect(java.util.stream.Collectors.toList());
                break;
            case "completed":
                tasks = dbHandler.getAllTasks().stream()
                    .filter(Task::isCompleted)
                    .collect(java.util.stream.Collectors.toList());
                break;
            default:
                tasks = dbHandler.getAllTasks();
                break;
        }

        totalTasks = dbHandler.getAllTasks().size();
        completedTasks = (int) dbHandler.getAllTasks().stream()
            .filter(Task::isCompleted)
            .count();

        updateTaskCount();

        for (Task task : tasks) {
            HBox taskRow = createTaskRow(task);
            taskListContainer.getChildren().add(taskRow);
        }

        if (tasks.isEmpty()) {
            Label emptyLabel = new Label("No tasks to display");
            emptyLabel.setFont(Font.font("Arial", 14));
            emptyLabel.setOpacity(0.6);
            taskListContainer.getChildren().add(emptyLabel);
        }
    }

    private HBox createTaskRow(Task task) {
        HBox taskRow = new HBox(10);
        taskRow.setPadding(new Insets(10));
        taskRow.setAlignment(Pos.CENTER_LEFT);
        taskRow.getStyleClass().add("task-row");

        CheckBox checkBox = new CheckBox();
        checkBox.setSelected(task.isCompleted());
        checkBox.setOnAction(e -> {
            task.setCompleted(checkBox.isSelected());
            dbHandler.updateTask(task);
            refreshTaskList(getCurrentFilter());
        });

        VBox taskInfo = new VBox(5);
        
        Label titleLabel = new Label(task.getTitle());
        titleLabel.getStyleClass().add("task-title");
        if (task.isCompleted()) {
            titleLabel.getStyleClass().add("completed");
        }

        HBox detailsBox = new HBox(10);
        
        Label descriptionLabel = new Label(task.getDescription());
        descriptionLabel.setOpacity(0.7);
        descriptionLabel.setWrapText(true);
        
        if (task.getDueDate() != null) {
            Label dateLabel = new Label("Due: " + task.getDueDate());
            dateLabel.getStyleClass().add("due-date");
            
            if (isOverdue(task.getDueDate()) && !task.isCompleted()) {
                dateLabel.getStyleClass().add("overdue");
            }
            detailsBox.getChildren().add(dateLabel);
        }
        
        if (!task.getDescription().isEmpty()) {
            detailsBox.getChildren().add(descriptionLabel);
        }

        taskInfo.getChildren().addAll(titleLabel, detailsBox);

        Button editBtn = new Button("Edit");
        editBtn.getStyleClass().add("edit-btn");
        editBtn.setOnAction(e -> showEditTaskDialog(task));

        Button deleteBtn = new Button("Delete");
        deleteBtn.getStyleClass().add("delete-btn");
        deleteBtn.setOnAction(e -> {
            dbHandler.deleteTask(task.getId());
            refreshTaskList(getCurrentFilter());
        });

        HBox buttonsBox = new HBox(10);
        buttonsBox.getChildren().addAll(editBtn, deleteBtn);

        HBox.setHgrow(taskInfo, Priority.ALWAYS);
        taskRow.getChildren().addAll(checkBox, taskInfo, buttonsBox);

        return taskRow;
    }

    private boolean isOverdue(String dueDate) {
        if (dueDate == null || dueDate.isEmpty()) {
            return false;
        }
        try {
            java.time.LocalDate due = java.time.LocalDate.parse(dueDate);
            return due.isBefore(java.time.LocalDate.now());
        } catch (Exception e) {
            return false;
        }
    }

    private void clearCompletedTasks() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Clear Completed Tasks");
        alert.setHeaderText("Are you sure you want to clear all completed tasks?");
        alert.setContentText("This action cannot be undone.");

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                dbHandler.clearCompletedTasks();
                refreshTaskList(getCurrentFilter());
            }
        });
    }

    private void exportTasks() {
        java.util.List<Task> tasks = dbHandler.getAllTasks();
        
        if (tasks.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Export Tasks");
            alert.setHeaderText("No tasks to export");
            alert.setContentText("Your task list is empty.");
            alert.showAndWait();
            return;
        }

        StringBuilder content = new StringBuilder();
        content.append("Smart To-Do List Export\n");
        content.append("======================\n\n");

        for (Task task : tasks) {
            content.append(String.format("[%s] %s\n", task.isCompleted() ? "✓" : " ", task.getTitle()));
            if (!task.getDescription().isEmpty()) {
                content.append("  Description: ").append(task.getDescription()).append("\n");
            }
            if (task.getDueDate() != null) {
                content.append("  Due Date: ").append(task.getDueDate()).append("\n");
            }
            content.append("\n");
        }

        javafx.stage.FileChooser fileChooser = new javafx.stage.FileChooser();
        fileChooser.setTitle("Export Tasks");
        fileChooser.setInitialFileName("tasks_export.txt");
        javafx.stage.FileChooser.ExtensionFilter extFilter = 
            new javafx.stage.FileChooser.ExtensionFilter("Text files (*.txt)", "*.txt");
        fileChooser.getExtensionFilters().add(extFilter);

        java.io.File file = fileChooser.showSaveDialog(null);
        if (file != null) {
            try (java.io.FileWriter writer = new java.io.FileWriter(file)) {
                writer.write(content.toString());
                
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Export Tasks");
                alert.setHeaderText("Export Successful");
                alert.setContentText("Tasks exported to: " + file.getName());
                alert.showAndWait();
            } catch (Exception e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Export Failed");
                alert.setHeaderText("Error exporting tasks");
                alert.setContentText(e.getMessage());
                alert.showAndWait();
            }
        }
    }

    private String getCurrentFilter() {
        Toggle selected = filterGroup.getSelectedToggle();
        if (selected == null) {
            return "all";
        }
        RadioButton rb = (RadioButton) selected;
        return rb.getText().toLowerCase();
    }

    private void updateTaskCount() {
        // Update the task count label in the bottom bar
        // This will be handled through the UI refresh
    }

    public static void main(String[] args) {
        launch(args);
    }
}

